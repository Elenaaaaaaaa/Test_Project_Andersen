package com.com.andersen.game.Capabilities;

import com.com.andersen.game.All_capabilities;

public interface MagicSupport {
    double magicSupportSkill(All_capabilities target);
}
