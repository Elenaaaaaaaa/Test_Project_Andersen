package com.com.andersen.game.Capabilities;

import com.com.andersen.game.All_capabilities;

public interface Melee {
    double meleeSkill(All_capabilities target);
}
