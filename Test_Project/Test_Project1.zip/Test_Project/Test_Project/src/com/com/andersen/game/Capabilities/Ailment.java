package com.com.andersen.game.Capabilities;

import com.com.andersen.game.All_capabilities;

public interface Ailment {
    double SendAilment (All_capabilities target);
}
