package com.com.andersen.game;

import com.com.andersen.game.Capabilities.MagicDamage;

public class Main {

    public static void main(String[] args) {
        //MagicDamage
}


}
