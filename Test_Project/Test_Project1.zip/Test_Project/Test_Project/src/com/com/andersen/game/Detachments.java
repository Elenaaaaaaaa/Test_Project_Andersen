package com.com.andersen.game;

import com.com.andersen.game.Elves.ElfArcher;
import com.com.andersen.game.Elves.ElfMagician;
import com.com.andersen.game.Elves.ElfWarrior;
import com.com.andersen.game.Orcs.ArcherB;
import com.com.andersen.game.Orcs.Goblin;
import com.com.andersen.game.Orcs.Shaman;
import com.com.andersen.game.People.Arbalester;
import com.com.andersen.game.People.PeopleMagician;
import com.com.andersen.game.People.PeopleWarrior;
import com.com.andersen.game.Undead.Hunter;
import com.com.andersen.game.Undead.Necromancer;
import com.com.andersen.game.Undead.Zombie;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Detachments {
    private All_capabilities newElves;
    private All_capabilities newPeople;
    private All_capabilities newOcrs;
    private All_capabilities newUndead;



    public All_capabilities getNewElves() {
        return newElves;
    }

    public All_capabilities getNewPeople() {
        return newPeople;
    }

    public All_capabilities getNewOcrs(){
        return newOcrs;
    }

    public All_capabilities getNewUndead(){
        return newUndead;
    }

    public All_capabilities generateElves (){
        Random randPerson = new Random();
        ArrayList<All_capabilities> lightElves = new ArrayList<>();
        final boolean add = lightElves.add(newElfMagician());
        final boolean add = lightElves.add(newElvesArcher());
        final boolean add = lightElves.add(newElvesArcher());
        final boolean add = lightElves.add(newElvesArcher());
        final boolean add = lightElves.add(newElvesArche());
        lightElves.add(new ElvesWarrior());
        lightElves.add(new ElvesWarrior());
        lightElves.add(new ElvesWarrior());
        lightElves.add(new ElvesWarrior());

        All_capabilities personElves = lightElves.get(randPerson.nextInt(lightElves.size()));

        if (personElves instanceof ElvesArcher) {
            newElves = ((ElvesArcher) personElves);
        }
        if (personElves instanceof ElvesMagican) {
            newElves = ((ElvesMagican) personElves);
        }
        if (personElves instanceof ElvesWarrior) {
            newElves = ((ElvesWarrior) personElves);
        }
        return newElves;
    }



    public All_capabilities generateOrcs(){
        Random randPerson = new Random();

        List<All_capabilities> kOrcs = new ArrayList<>();
        darkOrcs.add(new OrcShaman());
        darkOrcs.add(new OrcArcher());
        darkOrcs.add(new OrcArcher());
        darkOrcs.add(new OrcArcher());
        darkOrcs.add(new OrcGoblin());
        darkOrcs.add(new OrcGoblin());
        darkOrcs.add(new OrcGoblin());
        darkOrcs.add(new OrcGoblin());

        Hero personOrc = darkOrcs.get(randPerson.nextInt(darkOrcs.size()));

        if (personOrc instanceof OrcShaman) {
            newOcrs = ((OrcShaman) personOrc);
        }
        if (personOrc instanceof OrcArcher) {
            newOcrs = ((OrcArcher) personOrc);
        }
        if (personOrc instanceof OrcGoblin) {
            newOcrs = ((OrcGoblin) personOrc);
        }
        return newOcrs;
    }


    public Hero generetePeople () {
        Random randPerson = new Random();
        List<Hero> lightPeople = new ArrayList<>();
        lightPeople.add(new PeopleMagician());
        lightPeople.add(new PeopleCrossbowman());
        lightPeople.add(new PeopleCrossbowman());
        lightPeople.add(new PeopleCrossbowman());
        lightPeople.add(new PeopleWarrior());
        lightPeople.add(new PeopleWarrior());
        lightPeople.add(new PeopleWarrior());
        lightPeople.add(new PeopleWarrior());

        Hero personPeople = lightPeople.get(randPerson.nextInt(lightPeople.size()));

        if (personPeople instanceof ElvesArcher) {
            newPeople = ((PeopleMagician) personPeople);
        }
        if (personPeople instanceof ElvesMagican) {
            newPeople = ((PeopleCrossbowman) personPeople);
        }
        if (personPeople instanceof ElvesWarrior) {
            newPeople = ((PeopleWarrior) personPeople);
        }

        return newPeople;
    }

    public Hero genereteUndead () {
        Random randPerson = new Random();
        List<Hero> darkUndead = new ArrayList<>();
        darkUndead.add(new UndeadNecromancer());
        darkUndead.add(new UndeadHunter());
        darkUndead.add(new UndeadHunter());
        darkUndead.add(new UndeadHunter());
        darkUndead.add(new UndeadZombie());
        darkUndead.add(new UndeadZombie());
        darkUndead.add(new UndeadZombie());
        darkUndead.add(new UndeadZombie());

        Hero personUndead = darkUndead.get(randPerson.nextInt(darkUndead.size()));

        if (personUndead instanceof ElvesArcher) {
            newUndead = ((UndeadNecromancer) personUndead);
        }
        if (personUndead instanceof ElvesMagican) {
            newUndead = ((UndeadHunter) personUndead);
        }
        if (personUndead instanceof ElvesWarrior) {
            newUndead = ((UndeadZombie) personUndead);
        }
        return newUndead;
    }

    public Hero lightSide () {
        Random randPerson = new Random();

        List<Hero> lightSide = new ArrayList<>();
        lightSide.add(genereteElves());
        lightSide.add(generetePeople());

        Hero personOnLightSide = lightSide.get(randPerson.nextInt(lightSide.size()));

        return personOnLightSide;
    }

    public Hero darkSide () {
        Random randPerson = new Random();

        List<Hero> darkSide = new ArrayList<>();
        darkSide.add(genereteOrcs());
        darkSide.add(genereteUndead());

        Hero personOnDarkSide = darkSide.get(randPerson.nextInt(darkSide.size()));

        return personOnDarkSide;
    }

}
    }
}
