package com.com.andersen.game.Capabilities;

import com.com.andersen.game.All_capabilities;

public interface Shooting {
    double shootSkill(All_capabilities target);
}
