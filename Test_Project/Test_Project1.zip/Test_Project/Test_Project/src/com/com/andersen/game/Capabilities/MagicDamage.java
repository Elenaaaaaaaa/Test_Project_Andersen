package com.com.andersen.game.Capabilities;


import com.com.andersen.game.All_capabilities;

public interface MagicDamage {
    double magicDamageSkill(All_capabilities target);

}
