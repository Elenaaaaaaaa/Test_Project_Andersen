package com.com.andersen.game;

public enum Race {
    elf,
    people,
    orcs,
    undead
}
