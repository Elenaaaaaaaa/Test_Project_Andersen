package com.andersen.homework2;

public interface ShapeInterface {

    double calculateArea ();
    double calculatePerimeter();

}
